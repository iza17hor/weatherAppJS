const input = document.querySelector('input')
const button = document.querySelector('button')
const cityName = document.querySelector('.city-name')
const warning = document.querySelector('.warning')
const photo = document.querySelector('.photo')
const weather = document.querySelector('.weather')
const temperature = document.querySelector('.temperature')
const humidity = document.querySelector('.humidity')

let inputValue;

async function test () {
    inputValue = input.value;
    const URLweb = `https://api.openweathermap.org/data/2.5/weather?q=${input.value}&appid=528dad5e5a3ade659bccdc0142c493ff`
    const response = await axios.get(URLweb)
    humidity.textContent = `${response.data.main.humidity} %`
    temperature.textContent = Math.floor(response.data.main.temp)
    weather.textContent = response.data.weather[0].main

    console.log(response.data.weather[0].main)

    switch (response.data.weather[0].main)
    {
        case "Clear":
            photo.removeAttribute("src")
            photo.setAttribute("src", "./img/sun.png")
          break;
        case "Fog":
            photo.removeAttribute("src")
            photo.setAttribute("src", "./img/fog.png")
          break;
        case "Ice":
            photo.removeAttribute("src")
            photo.setAttribute("src", "./img/ice.png")
          break;
        case "Thunderstorm":
            photo.removeAttribute("src")
            photo.setAttribute("src", "./img/thunderstorm.png")
          break;
          case "Rain":
            photo.removeAttribute("src")
            photo.setAttribute("src", "./img/rain.png")
          break;
          case "Drizzle":
            photo.removeAttribute("src")
            photo.setAttribute("src", "./img/drizzle.png")
          break;
          case "Clouds":
            photo.removeAttribute("src")
            photo.setAttribute("src", "./img/cloud.png")
          break;
        
      } 
    }

button.addEventListener("click", test)





